# Multilevel Visibility Hash Filter

**Variance-driven shadow ray caching for real-time path tracing.**

Caches point-to-point binary visibility in a multilevel spatial hash table.
The cached mean serves as a control variate for shadow ray gating via Russian
roulette — concentrating traces on shadow boundaries while preserving
unbiasedness. Integrates with ReSTIR DI and GI pipelines.

## Lineage

The core idea — hash-backed spatial grid for visibility prediction with
control-variate Russian roulette — originates in [Kugelmann 2006], a
Diplomarbeit at Universität Ulm supervised by Alexander Keller. Key subsequent
building blocks: jitter-before-quantize filtering [Binder et al. 2018],
multilevel hashing [Müller et al. 2022], spatial×spatial visibility caching
[Guo et al. 2020 / NEE++]. This repo is the real-time GPU engineering
assembly.

## Architecture

```
┌─────────────────────────────────────────────┐
│  GraphicsBuffer: uint2[] (fp, packed_counts) │
│  Shared across L0 / L1 / L2 levels          │
│  8 bytes/entry × configurable capacity       │
└──────────────┬──────────────────────────────┘
               │
  ┌────────────┼────────────────────┐
  │            │                    │
Insert     Lookup              Decay
(any ray)  (any ray)       (background CS)
  │            │                    │
  ▼            ▼                    ▼
vc_insert  vc_find → VCShadowQuery  vc_decay_entry
  │            │                    │
  │   ┌────────┴────────┐          │
  │   │ CV+RRR decision │    tombstone on
  │   │ shouldTrace?    │    total == 0
  │   └────────┬────────┘
  │            │
  ▼            ▼
VCRecordShadow  VCEstimate / VCEstimateClamped
```

## Files

```
src/
  VisibilityCache.hlsl     672 lines  Core GPU implementation
  VisibilityCache.cs       361 lines  Unity C# host (config, dispatch, stats)
  VisibilityCache.compute   39 lines  Decay + clear compute kernels

paper/
  generate_paper.py        734 lines  ReportLab paper generator
  multilevel-visibility-hash-filter.pdf

docs/
  DESIGN.md                Full design document with equations
  EARLY_DESIGN.md          Earlier path-space hash filter iteration
  EVOLUTION.md             Design decision history (10 sessions)
  API.md                   Integration quickstart
```

## Key Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Entry size | 8 bytes (uint2) | Single atomic cacheline, fp + packed 16-bit counters |
| Hash table | Open addressing, double hashing | GPU-friendly, no pointer chasing |
| Jitter seed | `pcg3d(asuint(pos))` | Stochastic boundaries (reducible noise) vs cell-seeded sharp boundaries (irreducible bias) |
| Decay | Tunable right-shift (default /8) | Configurable half-life, consistent with overflow decay |
| Tombstones | `0xFFFFFFFE` | Preserve probe chains on decay; reclaimed on insert |
| Stats | `#ifdef VC_STATS_*` per counter group | Zero cost in production; INSERTS+EVICTIONS always on for autotune |
| CV+RRR | Cached mean on RR kill | Szirmay-Kalos "go with the winners" — lower variance than returning 0 |

## Quick Integration (Unity)

```csharp
// Setup
var config = new VisibilityCache.Config {
    capacity    = 1 << 20,  // 1M entries = 8 MB
    cellSizes   = new float3(0.5f, 2f, 8f),
    maxProbes   = 8,
    decayPeriod = 30,
    decayShift  = 3
};
var vc = new VisibilityCache(config, decayShader);
```

```hlsl
// In your ray generation / closest hit shader:
#include "VisibilityCache.hlsl"

VCShadowQuery q = VCQueryShadow(P, lightPos, cellSizes, rng);
if (q.shouldTrace) {
    bool vis = TraceVisibility(P, lightPos);
    VCRecordShadow(P, lightPos, vis);
    lighting = analytic * VCEstimate(q, vis);
} else {
    lighting = analytic * q.mean;
}
```

## Requirements

- Unity 2022+ with DXR support
- Shader Model 6.0+ (InterlockedAdd on RWStructuredBuffer)
- `VC_STATS_PROBES` / `VC_STATS_QUERIES` optional defines for profiling

## References

- [Kugelmann 2006] M. Kugelmann. "Efficient Adaptive Global Illumination Algorithms." Diplomarbeit, Universität Ulm. Supervisor: A. Keller.
- [Keller et al. 2016] A. Keller, N. Binder, K. Dahm. Hash-based path space filtering.
- [Binder et al. 2018] N. Binder, S. Fricke, A. Keller. "Path Space Filtering." GPU Zen 2.
- [Bitterli et al. 2020] ReSTIR DI. ACM Trans. Graph. 39(4).
- [Guo et al. 2020] NEE++. Pacific Graphics 2020.
- [Jarzynski & Olano 2020] pcg3d hash. JCGT 9(3).
- [Ouyang et al. 2021] ReSTIR GI. Computer Graphics Forum 40(8).
- [Müller et al. 2022] Instant-NGP multiresolution hash. ACM Trans. Graph. 41(4).
- [Lin et al. 2022] GRIS: Foundations of ReSTIR. ACM Trans. Graph. 41(4).
- [Szirmay-Kalos et al.] "Go with the winners" CV+RRR estimator.

## License

TBD

## Status

Design and implementation complete. No experimental validation yet.

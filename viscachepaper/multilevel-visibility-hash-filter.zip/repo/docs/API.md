# API Reference

## Setup (C#)

```csharp
using UnityEngine;
using UnityEngine.Rendering;

var config = new VisibilityCache.Config {
    capacity    = 1 << 20,   // entries (8 bytes each)
    cellSizes   = new float3(0.5f, 2f, 8f),  // L0, L1, L2 in world units
    maxProbes   = 8,
    decayPeriod = 30,        // frames between decay passes
    decayShift  = 3          // 1=halve, 2=quarter, 3=eighth (default), 4=sixteenth
};
var vc = new VisibilityCache(config, decayComputeShader);

// Per frame (in render pass setup):
vc.Update(cmd);
vc.Bind(cmd, computeShader, kernelIndex);
// or for material property blocks:
vc.Bind(cmd, materialPropertyBlock);
```

## GPU API (HLSL)

### Include

```hlsl
#include "VisibilityCache.hlsl"

// Optional profiling defines (before include):
// #define VC_STATS_PROBES    // per-probe-step counters (expensive)
// #define VC_STATS_QUERIES   // lookups + misses
// #define VC_STATS_DECAYS    // decay triggers
```

### Resources (set by C# Bind)

```hlsl
RWStructuredBuffer<uint2> _VCTable;
uint   _VCCapacity;
uint   _VCMaxProbes;
float3 _VCCellSize0, _VCCellSize1, _VCCellSize2;
uint   _VCFrame;
```

### Shadow Query + Record

```hlsl
// Step 1: Query cache
VCShadowQuery q = VCQueryShadow(
    float3 posA,        // shading point
    float3 posB,        // light position
    float3 cellSizes,   // _VCCellSize0 (or L1/L2)
    inout uint rng      // RNG state for RR decision
);

// q.shouldTrace  — true if RR says trace
// q.mean         — cached μ = visible_count / total_count
// q.variance     — σ² = μ(1−μ)
// q.weight       — total_count (0 = miss)

// Step 2: Trace if needed, always record
if (q.shouldTrace) {
    bool visible = TraceVisibilityRay(posA, posB);
    VCRecordShadow(posA, posB, visible);

    // Step 3: Combine with CV estimator
    float shadow = VCEstimate(q, visible);
    // or clamped version:
    float shadow = VCEstimateClamped(q, visible, 0.0, 1.0);

    lighting = analytic * shadow;
} else {
    // RR killed — use cached mean
    lighting = analytic * q.mean;
}
```

### Multilevel Query

```hlsl
// Query coarsest level first, refine if high variance
for (int level = 0; level < 3; level++) {
    float3 cs = level == 0 ? _VCCellSize0
              : level == 1 ? _VCCellSize1
              :              _VCCellSize2;

    VCShadowQuery q = VCQueryShadow(P, lightPos, cs, rng);
    if (q.weight > 0 && q.variance < threshold) {
        // Confident — use this level
        break;
    }
}
```

### Insert (multi-level, variance-gated)

```hlsl
// Typically called from ray generation after shadow ray result:
VCRecordShadow(posA, posB, visibility);  // inserts at all active levels

// Distance-gated: the C# side sets LOD interval based on camera distance.
// Insert writes L0 always, finer levels only where L0 variance > threshold.
```

### ReSTIR Integration

**DI target function** — multiply cached μ into light weight:
```hlsl
float targetPdf = luminance * cachedVisibility;  // from q.mean
```

**GI revalidation** — gate revalidation trace:
```hlsl
VCShadowQuery q = VCQueryShadow(currentP, reusedHitP, cellSizes, rng);
if (q.shouldTrace) {
    bool vis = TraceVisibility(currentP, reusedHitP);
    VCRecordShadow(currentP, reusedHitP, vis);
    revalidationWeight = VCEstimate(q, vis);
} else {
    revalidationWeight = q.mean;
}
```

## Stats (C#)

```csharp
var stats = vc.ReadStats();
// stats.inserts, stats.evictions — always available
// stats.lookups, stats.misses    — requires VC_STATS_QUERIES
// stats.probes                   — requires VC_STATS_PROBES
// stats.decays                   — requires VC_STATS_DECAYS

float loadPressure = stats.LoadPressure;      // evictions / inserts
float effectiveness = stats.CacheEffectiveness; // 1 - misses/lookups
float avgProbes = stats.AvgProbeDepth;          // probes / (inserts+lookups)
```

## Constants

| Name | Value | Purpose |
|------|-------|---------|
| `VC_EMPTY` | `0` | Empty slot marker (fp) |
| `VC_TOMBSTONE` | `0xFFFFFFFE` | Decayed slot, chain continues |
| `VC_OVERFLOW_SHIFT` | `3` | CAS overflow decay divisor |
| `VC_MAX_LEVELS` | `3` | L0 / L1 / L2 |

## Defines

| Define | Effect |
|--------|--------|
| `VC_STATS_PROBES` | Enable per-probe-step atomic counters (high perf cost) |
| `VC_STATS_QUERIES` | Enable lookups + misses counters |
| `VC_STATS_DECAYS` | Enable decay trigger counter |

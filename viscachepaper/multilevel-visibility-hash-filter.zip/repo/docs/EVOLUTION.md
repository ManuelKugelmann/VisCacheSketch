# Design Evolution

10 design sessions, Feb 11–Mar 3 2026. Chronological record of decisions.

---

## Session 1 — Multilevel Hashmap Foundations (Feb 11)

Initial exploration of multilevel spatial-directional hashmaps for ray tracing.
Compared addressing strategies (Morton codes vs direct quantization), collision
resolution (fingerprints vs neighbourhood search), and hierarchical approaches.

**Decisions:**
- Direct quantization over Morton codes (simpler, no scene bounds)
- Open addressing with fingerprints (GPU-friendly, no pointers)
- Multilevel shared table (L0/L1/L2 in single buffer)

---

## Session 2 — Complete Design Document (Feb 11)

Full design covering data structures, LOD coupling, variance-driven adaptation,
temporal decay, and comparisons with Binder/Gautron/MrHash/Instant-NGP.

**Decisions:**
- 6D domain: two 3D surface positions (point-to-point visibility)
- Variance-driven write depth: L0 always, finer levels only at boundaries
- Distance-gated LOD intervals by screen-space cell footprint

---

## Session 3 — Octahedral Quantization (Feb 12)

Added directional quantization for infinite endpoints (IBL, directional lights).
Solid angle distortion compensation via weighting.

**Decisions:**
- Octahedral mapping for angular quantization
- `0x7FFF7FFF` z-sentinel distinguishes angular from positional entries
- Float weight_sum replaced integer count for proper area compensation

---

## Session 4 — Control Variate + RR (Feb 12)

Extended from pure cache to control-variate estimator with Russian roulette.
First paper draft generated.

**Decisions:**
- CV+RRR: return cached μ on RR kill (Szirmay-Kalos "go with the winners")
- Bernoulli variance σ² = μ(1−μ) drives trace probability
- Self-regulating loop: boundaries get more traces → better estimates → fewer traces

---

## Session 5 — Visibility-Specific Simplification (Feb 12)

Stripped to binary visibility (V ∈ {0,1}). 8-byte entries. Full implementation.

**Key simplifications:**
- Packed uint: two 16-bit counters (visible_count, total_count) in single atomic
- Removed float weight_sum — integer counts sufficient for binary
- CAS overflow decay: halve both counters when total approaches 2¹⁶
- pcg3d hash specification [Jarzynski & Olano 2020]
- Runtime statistics with auto-decay tuning
- Distance-gated LOD intervals (4×4 to 64×64 pixel footprint targets)

---

## Session 6 — Infinity Flag + Angular Quantization (Feb 13)

Added is_inf flag for IBL/directional lights selecting angular vs positional
quantization. Updated pixel footprint targets to square values.

---

## Session 7 — Lineage Attribution (Feb 13)

Critical session: corrected attribution to Kugelmann [2006] Diplomarbeit as
direct ancestor (hash-backed visibility cache with CV+RRR under Keller).
Established clean chronological lineage:

  Teschner 2003 (spatial hashing) → Szirmay-Kalos (CV+RRR) →
  Kugelmann 2006 (combined for visibility) → Binder 2018 (PSF jitter) →
  Guo 2020 (NEE++ independent rediscovery) → Müller 2022 (multilevel hash) →
  This work (real-time GPU assembly)

---

## Session 8 — Citation Formatting + CV+RRR Terminology (Feb 13)

Standardized citations to [Names, Year] format. Refined CV+RRR terminology.
Restructured intro with clean lineage paragraph. Session 8 abstract and intro
became the canonical versions.

---

## Session 9 — Jitter, Tombstones, Stats, Decay (Feb 26)

Five design concerns audited and resolved:

### 9.1 Tombstones
Decay setting fp=0 broke probe chains. Fix: `VC_TOMBSTONE = 0xFFFFFFFE`.
- `vc_find`: skips tombstones, chain continues
- `vc_insert_at_level`: reclaims tombstones (earlier slot = shorter probes)
- `vc_decay_entry`: writes tombstone when total==0
- `vc_hash_fp`: avoids both 0 (empty) and tombstone values

### 9.2 Tunable Decay
Added `Config.decayShift` [1-4]: `vis -= vis >> shift`. Default 3 (÷8),
consistent with overflow decay `VC_OVERFLOW_SHIFT=3`.

### 9.3 Auto-Clear
`_needsClear` flag — first `Update()` clears table automatically.
Prevents first-frame garbage reads from uninitialized GraphicsBuffer.

### 9.4 Jitter Evolution

**Pixel-based salt** → **position-based salt** → **remove frame component** →
**remove salt entirely**.

Final: `pcg3d(asuint(pos))` — raw float bits as seed. Each unique surface
point gets independent stable jitter. No salt infrastructure, no pixelCoord
parameter, no frame number.

Removed ~30 lines of salt code.

### 9.5 Stats Optimization

6-16M atomics/frame to single cache line. Granular `#ifdef` wrapping:
- `VC_STATS_PROBES`: highest impact (60-70% of all atomics), inner loop
- `VC_STATS_QUERIES`: LOOKUPS + MISSES
- `VC_STATS_DECAYS`: background only, zero hot-path impact
- INSERTS + EVICTIONS: always on (needed for autotune)

---

## Session 10 — Stochastic Jitter + Paper Polish (Mar 3)

### 10.1 PSF vs Stochastic Jitter Analysis

Two approaches analyzed:

| | Seed | Boundary behavior | Filtering |
|---|---|---|---|
| PSF [Binder 2018] | `pcg3d(floor(pos/cell))` | Sharp steps (irregular but fixed) | Cell-internal average |
| Ours | `pcg3d(asuint(pos))` | Probabilistic membership | Spatial denoiser / accumulation |

**Decision: stochastic only, no `#define` switch.**

Rationale: cell-seeded boundaries = persistent bias (irreducible, does not
diminish with accumulation). Position-seeded dilution = noise (reducible).
Eliminating bias at the cost of slightly more reducible variance is the
standard Monte Carlo trade-off. The denoiser benefits, but is not the reason
— the raw unfiltered output has lower base error.

PSF chose coherent jitter because it targeted offline rendering (many SPP,
no spatial denoiser). Cell average was the only filter. Our context: 1 SPP,
denoiser always present, but correctness argument holds without it.

### 10.2 Paper Updates
- Section 4 (Addressing): stochastic vs coherent jitter rationale
- Abstract: restored session 8 version (solution-first, no lineage)
- Intro: restored session 7/8 chronological lineage with Kugelmann [2006]
- Author: M. Kugelmann
- Added references: [Kugelmann 2006], [Keller et al. 2016]
- Layout: tightened title frame, forced §2 to right column, §3 to page 2

---

## Current State (Mar 3 2026)

### Implementation: complete
- `VisibilityCache.hlsl` — 672 lines, all GPU logic
- `VisibilityCache.cs` — 361 lines, Unity host
- `VisibilityCache.compute` — 39 lines, decay + clear kernels

### Paper: draft complete, no experimental results
- 5 pages, two-column format
- All sections written through §11 (Cache-Free Alternatives)
- TODOs: performance measurements, convergence plots, comparisons

### Open items
- Experimental validation
- Weighted insertion (4-bit quantized weights for non-binary signals)
- Warp-aggregated atomics (SM 6.5+ WaveActiveSum before InterlockedAdd)
- Cache-line padding for stats buffer (marginal benefit)
